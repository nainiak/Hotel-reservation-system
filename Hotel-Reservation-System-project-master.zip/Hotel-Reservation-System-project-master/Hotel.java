import java.io.Serializable;
import java.time.LocalDate;
import java.util.ArrayList;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Manages all hotel operations, including rooms and reservations.
 */
public class Hotel implements Serializable {
    private static final long serialVersionUID = 1L;

    private List<Room> rooms;
    private List<Reservation> reservations;
    private int nextReservationId = 1;

    /**
     * Constructs a new Hotel and initializes its rooms.
     */
    public Hotel() {
        this.rooms = new ArrayList<>();
        this.reservations = new ArrayList<>();
        initializeRooms();
    }

    /**
     * Populates the hotel with a default set of rooms.
     */
    private void initializeRooms() {
        // Add Standard rooms
        for (int i = 101; i <= 105; i++) {
            rooms.add(new Room(i, "Standard", 100.00));
        }
        // Add Deluxe rooms
        for (int i = 201; i <= 203; i++) {
            rooms.add(new Room(i, "Deluxe", 150.00));
        }
        // Add Suite rooms
        rooms.add(new Room(301, "Suite", 250.00));
    }

    /**
     * Searches for available rooms of a specific category.
     * @param category The desired room category.
     * @return A list of available rooms.
     */
    public List<Room> searchAvailableRooms(String category) {
        return rooms.stream()
                .filter(room -> room.getCategory().equalsIgnoreCase(category) && room.isAvailable())
                .collect(Collectors.toList());
    }

    /**
     * Makes a reservation for a guest.
     * @param guestName The name of the guest.
     * @param roomNumber The number of the room to book.
     * @param checkInDate The check-in date.
     * @param checkOutDate The check-out date.
     * @return The created Reservation object, or null if booking fails.
     */
    public Reservation makeReservation(String guestName, int roomNumber, LocalDate checkInDate, LocalDate checkOutDate) {
        Room roomToBook = rooms.stream()
                .filter(room -> room.getRoomNumber() == roomNumber && room.isAvailable())
                .findFirst()
                .orElse(null);

        if (roomToBook != null) {
            roomToBook.bookRoom();
            Reservation reservation = new Reservation(nextReservationId++, guestName, roomToBook, checkInDate, checkOutDate);
            reservations.add(reservation);
            
            // Simulate payment
            Payment payment = new Payment(reservation.getReservationId(), reservation);
            if (payment.processPayment()) {
                 System.out.println("Reservation successful for " + guestName);
                 return reservation;
            } else {
                 // Rollback booking if payment fails
                 roomToBook.releaseRoom();
                 reservations.remove(reservation);
                 System.out.println("Payment failed. Reservation cancelled.");
                 return null;
            }
        }
        return null; // Room not found or not available
    }

    /**
     * Finds a reservation by its ID.
     * @param reservationId The ID of the reservation to find.
     * @return The Reservation object, or null if not found.
     */
    public Reservation findReservationById(int reservationId) {
        return reservations.stream()
                .filter(res -> res.getReservationId() == reservationId)
                .findFirst()
                .orElse(null);
    }
    
    /**
     * Cancels an existing reservation.
     * @param reservationId The ID of the reservation to cancel.
     * @return true if cancellation was successful, false otherwise.
     */
    public boolean cancelReservation(int reservationId) {
        Reservation reservationToCancel = findReservationById(reservationId);

        if (reservationToCancel != null) {
            reservationToCancel.getRoom().releaseRoom();
            reservations.remove(reservationToCancel);
            System.out.println("Reservation " + reservationId + " has been cancelled.");
            return true;
        }
        System.out.println("Reservation not found.");
        return false;
    }
    
    public List<Room> getAllRooms() {
        return rooms;
    }
}

