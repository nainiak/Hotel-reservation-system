import java.io.*;
import java.time.LocalDate;
import java.time.format.DateTimeFormatter;
import java.time.format.DateTimeParseException;
import java.util.List;
import java.util.Scanner;

/**
 * The main class for the Hotel Reservation System.
 * Handles user interaction and orchestrates the application flow.
 */
public class HotelReservationSystem {

    private static final String DATA_FILE = "hotel.dat";
    private Hotel hotel;
    private Scanner scanner;

    public HotelReservationSystem() {
        this.hotel = loadHotelData(); // Load existing data or create a new hotel
        this.scanner = new Scanner(System.in);
    }

    public static void main(String[] args) {
        HotelReservationSystem system = new HotelReservationSystem();
        system.run();
    }

    /**
     * The main loop of the application.
     */
    public void run() {
        while (true) {
            showMenu();
            int choice = getUserChoice();
            scanner.nextLine(); // Consume newline

            switch (choice) {
                case 1:
                    searchRooms();
                    break;
                case 2:
                    makeReservation();
                    break;
                case 3:
                    viewBookingDetails();
                    break;
                case 4:
                    cancelReservation();
                    break;
                case 5:
                    saveHotelData();
                    System.out.println("Exiting the system. Goodbye!");
                    return;
                default:
                    System.out.println("Invalid choice. Please try again.");
            }
        }
    }

    private void showMenu() {
        System.out.println("\n--- Hotel Reservation System ---");
        System.out.println("1. Search for available rooms");
        System.out.println("2. Make a reservation");
        System.out.println("3. View booking details");
        System.out.println("4. Cancel a reservation");
        System.out.println("5. Exit");
        System.out.print("Enter your choice: ");
    }

    private int getUserChoice() {
        while (!scanner.hasNextInt()) {
            System.out.println("Invalid input. Please enter a number.");
            scanner.next(); // discard non-integer input
            System.out.print("Enter your choice: ");
        }
        return scanner.nextInt();
    }

    private void searchRooms() {
        System.out.print("Enter room category (Standard, Deluxe, Suite): ");
        String category = scanner.nextLine();
        List<Room> availableRooms = hotel.searchAvailableRooms(category);

        if (availableRooms.isEmpty()) {
            System.out.println("No available rooms in the '" + category + "' category.");
        } else {
            System.out.println("\nAvailable Rooms:");
            availableRooms.forEach(System.out::println);
        }
    }

    private void makeReservation() {
        System.out.print("Enter your name: ");
        String guestName = scanner.nextLine();

        System.out.print("Enter room number to book: ");
        int roomNumber = getUserChoice();
        scanner.nextLine(); // Consume newline

        DateTimeFormatter formatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
        LocalDate checkInDate, checkOutDate;

        try {
            System.out.print("Enter check-in date (yyyy-MM-dd): ");
            checkInDate = LocalDate.parse(scanner.nextLine(), formatter);
            System.out.print("Enter check-out date (yyyy-MM-dd): ");
            checkOutDate = LocalDate.parse(scanner.nextLine(), formatter);
        } catch (DateTimeParseException e) {
            System.out.println("Invalid date format. Please use yyyy-MM-dd.");
            return;
        }

        Reservation reservation = hotel.makeReservation(guestName, roomNumber, checkInDate, checkOutDate);
        if (reservation == null) {
            System.out.println("Failed to make a reservation. The room might be unavailable or does not exist.");
        }
    }

    private void viewBookingDetails() {
        System.out.print("Enter your reservation ID: ");
        int reservationId = getUserChoice();
        scanner.nextLine(); // Consume newline

        Reservation reservation = hotel.findReservationById(reservationId);
        if (reservation != null) {
            System.out.println("\n--- Booking Details ---");
            System.out.println(reservation);
        } else {
            System.out.println("No booking found with the given ID.");
        }
    }

    private void cancelReservation() {
        System.out.print("Enter reservation ID to cancel: ");
        int reservationId = getUserChoice();
        scanner.nextLine(); // Consume newline

        if (hotel.cancelReservation(reservationId)) {
            // Success message is printed in the Hotel class
        } else {
            // Error message is printed in the Hotel class
        }
    }
    
    /**
     * Saves the current state of the hotel (rooms and reservations) to a file.
     */
    private void saveHotelData() {
        try (ObjectOutputStream oos = new ObjectOutputStream(new FileOutputStream(DATA_FILE))) {
            oos.writeObject(hotel);
            System.out.println("Hotel data saved successfully.");
        } catch (IOException e) {
            System.err.println("Error saving hotel data: " + e.getMessage());
        }
    }

    /**
     * Loads the hotel state from a file. If the file doesn't exist, it creates a new Hotel object.
     * @return The loaded or new Hotel object.
     */
    private Hotel loadHotelData() {
        try (ObjectInputStream ois = new ObjectInputStream(new FileInputStream(DATA_FILE))) {
            Hotel loadedHotel = (Hotel) ois.readObject();
            System.out.println("Hotel data loaded successfully.");
            return loadedHotel;
        } catch (FileNotFoundException e) {
            System.out.println("No existing data file found. Starting with a new hotel.");
            return new Hotel();
        } catch (IOException | ClassNotFoundException e) {
            System.err.println("Error loading hotel data: " + e.getMessage());
            return new Hotel(); // Start fresh if data is corrupted
        }
    }
}

