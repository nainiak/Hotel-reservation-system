import java.io.Serializable;

/**
 * Represents a hotel room.
 * Implements Serializable to allow room objects to be written to a file.
 */
public class Room implements Serializable {
    // A unique version identifier for serialization to prevent version conflicts.
    private static final long serialVersionUID = 1L;

    private int roomNumber;
    private String category; // e.g., Standard, Deluxe, Suite
    private double price;
    private boolean isAvailable;

    /**
     * Constructs a new Room.
     * @param roomNumber The unique number of the room.
     * @param category The category of the room.
     * @param price The price per night.
     */
    public Room(int roomNumber, String category, double price) {
        this.roomNumber = roomNumber;
        this.category = category;
        this.price = price;
        this.isAvailable = true; // A new room is available by default.
    }

    // --- Getters ---
    public int getRoomNumber() {
        return roomNumber;
    }

    public String getCategory() {
        return category;
    }

    public double getPrice() {
        return price;
    }

    public boolean isAvailable() {
        return isAvailable;
    }

    // --- Setters ---
    public void bookRoom() {
        this.isAvailable = false;
    }

    public void releaseRoom() {
        this.isAvailable = true;
    }

    /**
     * Returns a string representation of the room, useful for display.
     */
    @Override
    public String toString() {
        return "Room Number: " + roomNumber + ", Category: " + category + ", Price: $" + String.format("%.2f", price) + ", Available: " + (isAvailable ? "Yes" : "No");
    }
}

