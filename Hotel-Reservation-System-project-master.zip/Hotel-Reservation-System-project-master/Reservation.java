import java.io.Serializable;
import java.time.LocalDate;

/**
 * Represents a reservation made by a guest.
 * Implements Serializable to allow reservation objects to be saved.
 */
public class Reservation implements Serializable {
    private static final long serialVersionUID = 1L;

    private int reservationId;
    private String guestName;
    private Room room;
    private LocalDate checkInDate;
    private LocalDate checkOutDate;

    /**
     * Constructs a new Reservation.
     * @param reservationId A unique ID for the reservation.
     * @param guestName The name of the guest.
     * @param room The room being reserved.
     * @param checkInDate The check-in date.
     * @param checkOutDate The check-out date.
     */
    public Reservation(int reservationId, String guestName, Room room, LocalDate checkInDate, LocalDate checkOutDate) {
        this.reservationId = reservationId;
        this.guestName = guestName;
        this.room = room;
        this.checkInDate = checkInDate;
        this.checkOutDate = checkOutDate;
    }

    // --- Getters ---
    public int getReservationId() {
        return reservationId;
    }

    public String getGuestName() {
        return guestName;
    }

    public Room getRoom() {
        return room;
    }

    /**
     * Returns a string representation of the reservation details.
     */
    @Override
    public String toString() {
        return "Reservation ID: " + reservationId +
               "\nGuest Name: " + guestName +
               "\nRoom: " + room.getRoomNumber() + " (" + room.getCategory() + ")" +
               "\nCheck-in: " + checkInDate +
               "\nCheck-out: " + checkOutDate;
    }
}

