import java.io.Serializable;
import java.time.LocalDate;
import java.time.temporal.ChronoUnit;

/**
 * Handles the payment simulation for a reservation.
 */
public class Payment implements Serializable {
    private static final long serialVersionUID = 1L;

    private int paymentId;
    private int reservationId;
    private double amount;
    private LocalDate paymentDate;

    /**
     * Constructs a new Payment.
     * @param paymentId A unique ID for the payment.
     * @param reservation The reservation for which payment is being made.
     */
    public Payment(int paymentId, Reservation reservation) {
        this.paymentId = paymentId;
        this.reservationId = reservation.getReservationId();
        this.paymentDate = LocalDate.now();
        this.amount = calculateTotalAmount(reservation);
    }

    /**
     * Calculates the total cost of the stay.
     * @param reservation The reservation details.
     * @return The total amount to be paid.
     */
    private double calculateTotalAmount(Reservation reservation) {
        long numberOfNights = ChronoUnit.DAYS.between(reservation.getRoom().isAvailable() ? LocalDate.now() : LocalDate.now().plusDays(1), reservation.getRoom().isAvailable() ? LocalDate.now().plusDays(1) : LocalDate.now().plusDays(2));
        if (numberOfNights <= 0) {
            numberOfNights = 1; // Minimum 1-night charge
        }
        return reservation.getRoom().getPrice() * numberOfNights;
    }

    public double getAmount() {
        return amount;
    }

    /**
     * Simulates processing the payment.
     * @return true if the payment is successful, false otherwise.
     */
    public boolean processPayment() {
        // In a real application, this would integrate with a payment gateway.
        System.out.println("Processing payment of $" + String.format("%.2f", amount) + " for reservation ID " + reservationId);
        // Simulate a successful payment.
        System.out.println("Payment successful!");
        return true;
    }
}

